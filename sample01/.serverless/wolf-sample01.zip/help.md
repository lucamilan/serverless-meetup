# help #

sls deploy -s dev
sls invoke -f hello
sls logs -f hello