# help sls #

sls deploy -s dev
sls invoke -f hello
sls logs -f hello [-t tail mode]
sls info -s dev

# help npm #

npm init
npm list -g aws-sdk