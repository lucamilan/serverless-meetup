# app #

Bucket:
WWW - http://wolf-web-app.s3-website-eu-west-1.amazonaws.com

Api:
GET - https://sgljqiu2nh.execute-api.eu-west-1.amazonaws.com/dev/hello