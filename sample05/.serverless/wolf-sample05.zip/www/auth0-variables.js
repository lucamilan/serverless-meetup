var AUTH0_CLIENT_ID='zSIkjbVKVgvROA7jQEfmolnjiWIf567Q';
var AUTH0_DOMAIN='lucamilan.eu.auth0.com';
var API_URL='https://sgljqiu2nh.execute-api.eu-west-1.amazonaws.com/dev/hello';
